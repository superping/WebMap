/**
 * Created by superping on 2014/7/10.
 */

var density = window.devicePixelRatio;
console.log("density:"+density);
var riseOffset = 100 * density;


var tiletemplateString;
var isAndroid = false;
if (L.Browser.android || L.Browser.android23) {
    tiletemplateString = 'File:///mnt/sdcard/mapimage/satellite/tiles/{z}/{x}/{y}.png';
    isAndroid = true;
} else {
    tiletemplateString = 'h:/mapimage/satellite/tiles/{z}/{x}/{y}.png';
}



var map = L.map('map',
    {
        attributionControl: false
    }
).setView([ 23.1740636, 113.4093064 ], 16);



L.tileLayer(tiletemplateString,
    {
        maxZoom: 20
    }).addTo(map);



function onMapClick(e) {
    if (isAndroid) {
        mapjs.OnMapClick(e.latlng.lat, e.latlng.lng);
    }
}


function onMapLoaded(e) {
    if (isAndroid) {
        mapjs.OnLoaded();
    }
}


function onCameraChange(e) {
    var latlng = map.getCenter();
    var zoom = map.getZoom();
    console.log("lat:"+latlng.lat+",lng:"+latlng.lng+",zoom:"+zoom);
    // android function
    if (isAndroid) {
        mapjs.OnCameraChange(latlng.lat, latlng.lng, zoom, 0, 0);
    }
}

function onMarkerDragStart(e) {
    var marker = e.target;
    var markerItem = findItemByItem(markerArray, marker, 0, markerArray.length);
    // android window function
    if (isAndroid) {
        mapjs.OnMarkerDragStart(markerItem.id);
    }
}

function onMarkerDrag(e) {
    var marker = e.target;
    var markerItem = findItemByItem(markerArray, marker, 0, markerArray.length);
    // android window function
    if (isAndroid) {
        var latlng = markerItem.item.getLatLng();
        mapjs.OnMarkerDrag(markerItem.id, latlng.lat, latlng.lng);
    }

}

function onMarkerDragEnd(e) {
    var marker = e.target;
    var markerItem = findItemByItem(markerArray, marker, 0, markerArray.length);
    // android window function
    if (isAndroid) {
        mapjs.OnMarkerDragEnd(markerItem.id);
    }
}


//map.on("drag", onCameraChange);
//map.on("zoomlevelschange", onCameraChange);
//map.on("zoomend",onCameraChange );
//map.on("click", onMapClick);
//map.on("load", onMapLoaded);

var density;
function setDensity(densityparam) {
    density = densityparam;
}

var MarkerSrc = "icon/ic_waypoint.png";
var MarkerString = "<div  id = '{markerID}' style=\" width:{width}px; height:{height}px;align-self: center\"><img id ='{markerImageId}' src='{markerSrc}' style=' width:{width}px; height:{height}px;'/></div>";

var markerArray = [];

//Marker构造函数
function MarkerItem(index, marker) {
    this.id = index;
    this.item = marker;
}

//创建Marker
function createMarker(jsonText) {
    var id = jsonText.id;
    var createString = MarkerString.replace("{markerId}", "item" + id).replace("{markerImageId}", "markerImage" + id).replace("{width}", jsonText.width).replace("{height}", jsonText.height);
    if (jsonText.icon != null) {

        if (isAndroid) {
//        formImg.src = "data:image/png;base64," + jsonText.icon;
          createString = createString.replace("{markerSrc}", "data:image/png;base64," + jsonText.icon);
        } else {
          createString = createString.replace("{markerSrc}", jsonText.icon);
        }
    } else {
        createString = createString.replace("{markerSrc}", "icon/ic_waypoint.png");
    }
    console.log(createString);
    var waypointIcon = L.divIcon(
        {className: 'plane-div-icon',
            html: createString,
            iconAnchor: [jsonText.width * jsonText.anchorU, jsonText.height * jsonText.anchorV]});
    var marker = L.marker([jsonText.latitude, jsonText.longitude], {
            icon: waypointIcon,
            draggable: true
        }
    )
    if (jsonText.visible == true) {
        marker.addTo(map);
    }
//    var formImg = document.getElementById("markerImage" + id);
//    if (formImg != null) {
//
//        if (isAndroid) {
//            formImg.src = "data:image/png;base64," + jsonText.icon;
//        } else {
//            formImg.src = jsonText.icon;
//        }
//    }
    marker.on('dragstart', onMarkerDragStart);
    marker.on('drag', onMarkerDrag);
    marker.on('dragend', onMarkerDragEnd);
//    marker.dragging.disable();
//    marker.on('mousedown', onMarkerMousedown);
    var markerItem = new MarkerItem(id, marker);

    markerArray.push(markerItem);
}

//设置Marker属性
function setMarkerProperty(jsonText) {
    var item = jsonText.property;
    var id = jsonText.id;
    var markerItem = findItemById(markerArray, id, 0, markerArray.length - 1);
    if (markerItem == null) return;
    if (item == "position") {
        var latitude = jsonText.latitude;
        var longitude = jsonText.longitude;
        markerItem.item.setLatLng(latitude, longitude);
        markerItem.item.update();
    } else if (item == "rotation") {
        var angle = jsonText.rotation;
        var rotateImg = document.getElementById("markerImage" + id);
        rotate(rotateImg, angle);
    }
    else if (item == "draggable") {
        var draggable = jsonText.draggable;
        if (draggable == true) {
            markerItem.item.dragging.enable();
        } else {
            markerItem.item.dragging.disable();
        }
    }
    else if (item == "icon") {
        var markerIcon = L.divIcon(
            {className: 'plane-div-icon',
                html: MarkerString.replace("{markerId}", "item" + id).replace("{markerImageId}", "markerImage" + id).replace("{width}", jsonText.width).replace("{height}", jsonText.height),
                iconAnchor: [jsonText.width * jsonText.anchorU, jsonText.height * jsonText.anchorV]});
        markerItem.item.setIcon(markerIcon);
        var formImg = document.getElementById("markerImage" + id);
        if (isAndroid) {
            console.log(formImg.src);
            formImg.src = "data:image/png;base64," + jsonText.icon;
        }
    }
    else if (item == "visible") {
        if (jsonText.visible == true) {
            markerItem.item.addTo(map);
        } else {
            map.removeLayer(markerItem.item);
        }
    }
    else if (item == "anchor") {
    }
}
//获取Marker属性
function getMarkerProperty(jsonText) {
    var id = jsonText.id;
    var markerItem = findItemById(markerArray, id, 0, markerArray.length - 1);
    if (markerItem == null) return;
    var property = jsonText.property;
    switch (property) {
        case "position":
            var latlng = markerItem.item.getLatLng();
            // android window function
            if(isAndroid) {
                mapjs.markerPositionReturn(id, latlng.lat, latlng.lng);
            }
            break;
        case "icon":
            break;
        case "anchor":
            break;

    }
}
//移除Marker　
function removeMarker(jsonText) {
    var id = jsonText.id;
    var markerItem = findItemById(markerArray, id, 0, markerArray.length - 1);
    map.removeLayer(markerItem.item);
    markerArray.remove(markerItem);
}

var polylineArray = [];
//多点线构造函数
function PolylineItem(index, polyline) {
    this.id = index;
    this.item = polyline;
}

//新建多点线
function createPolyline(jsonText) {
    var id = jsonText.id;
    var count = jsonText.count;

    var latlngs = [];

    for (var index in (jsonText.latlngs)) {
        var latlngpoint = L.latLng(jsonText.latlngs[index].latitude, jsonText.latlngs[index].longitude);
        latlngs.push(latlngpoint);
    }
    var polyline = L.polyline(latlngs, {
        color: jsonText.color,
        weight: jsonText.width,
        clickable: false
    }).addTo(map);

    var polylineItem = new PolylineItem(id, polyline);

    polylineArray.push(polylineItem);
}

//移除Polyline
function removePolyline(jsonText) {
    var id = jsonText.id;
    var polylineItem = findItemById(polylineArray, id, 0, polylineArray.length - 1);
    map.removeLayer(polylineItem.item);
    polylineArray.remove(polylineItem);
}

//设置Polyline属性
function setPolylineProperty(jsonText) {
    var id = jsonText.id;
    var count = jsonText.count;

    var property = jsonText.property;
    var polylineItem = findItemById(polylineArray, id, 0, polylineArray.length - 1);
    if (polylineItem == null) return;

    switch (property) {
        case "latlngs":
            var latlngs = [];

            for (var index in (jsonText.latlngs)) {
                var latlngpoint = L.latLng(jsonText.latlngs[index].latitude, jsonText.latlngs[index].longitude);
                latlngs.push(latlngpoint);
            }
            polylineItem.item.setLatLngs(latlngs);
            polylineItem.item.redraw();
            break;
        case "color":
            var color = jsonText.color;
            var alpha = (jsonText.color & 0xff000000);
            alpha = (alpha >>> 24) / 0x100;
            var red = (jsonText.color & 0x00ff0000) / 0x100000;
            var green = (jsonText.color & 0x0000ff00) / 0x1000;
            var blue = (jsonText.color & 0x000000ff) / 0x10;
            var polycolor = '#' + Math.floor(red).toString(16) + Math.floor(green).toString(16) + Math.floor(blue).toString(16);
            polylineItem.item.setStyle({
                color: polycolor,
                opacity: alpha
            });
            break;
        case "width":
            polylineItem.item.setStyle({
                weight: jsonText.width
            });
            break;
        case "visible":
            if (jsonText.visible == true) {
                polylineItem.item.addTo(map);
            } else {
                map.removeLayer(polylineItem.item);
            }
    }

}




var timer;
function onMarkerClick(e) {
    var marker = e.target;
//    var markerItem = findItemByItem(markerArray, marker, 0, markerArray.length);
    var handler = function () {
        var latlng = marker.getLatLng();
        var point = map.latLngToContainerPoint(latlng);
        point.y = point.y - 100;
        latlng = map.containerPointToLatLng(point);
        marker.setLatLng(latlng);
    }
    timer = setInterval(handler, 1000);
}

//function onMarkerMousedown(e) {
//    var marker = e.target;
//    var markerItem = findItemByItem(markerArray, marker, 0, markerArray.length);
//    var handler = function () {
//        var latlng = marker.getLatLng();
//        var point = map.latLngToContainerPoint(latlng);
//        point.y = point.y - riseOffset;
//        latlng = map.containerPointToLatLng(point);
//        marker.setLatLng(latlng);
//        clearInterval(timer);
//
//        marker.dragging.enable();
//        marker.on('dragstart', onMarkerDragStart);
//        marker.on('drag', onMarkerDrag);
//        marker.on('dragend', onMarkerDragEnd);
//    }
//    timer = setInterval(handler, 1000);
//
//    function onMarkerMouseout(e) {
//        clearInterval(timer);
//        marker.dragging.disable();
//        marker.off('mouseout', onMarkerMouseout);
//        marker.off('dragstart', onMarkerDragStart);
//        marker.off('drag', onMarkerDrag);
//        marker.off('dragend', onMarkerDragEnd);
//    }
//
//    marker.on('mouseout', onMarkerMouseout);
//}


// BinarySearch
function findItemById(array, id, start, end) {
    console.log("find" + id + "," + start + "," + array[start].id + "," + end + "," + array[end].id);
    if (id == array[start].id) return array[start];
    if (id == array[end].id) return array[end];
    if (start == end) return null;

    var middle = Math.floor((start + end) / 2);
    if (middle < 0) middle = 0;
    if (middle == start || middle == end) return null;
    var middleItem = array[middle];
    if (middleItem == null) return null;
    console.log("middle" + middle + "," + middleItem.id);
    if (middleItem.id == id) return middleItem;
    if (middleItem.id < id) return findItemById(array, id, start, middle);
    else  return findItemById(array, id, middle, end);
}

// BinarySearch
function findItemByItem(array, item, start, end) {
    for (var index = start; index <= end; index++) {
        if (array[index].item == item) {
            return array[index];
        }
    }
    return null;
}

//旋转
function rotate(element, r) {
    element.style.MozTransform = "rotate(" + r + "deg)";
    element.style.webkitTransform = "rotate(" + r + "deg)";
    element.style.msTransform = "rotate(" + r + "deg)";
    element.style.OTransform = "rotate(" + r + "deg)";
    element.style.transform = "rotate(" + r + "deg)";
}

//屏幕到经纬度映射
function screenToLatlng(x, y) {
    var latlng = map.containerPointToLatLng(x / density, y / density);
    // android window function\
    mapjs.LatLngCallback(latlng.lat, latlng.lng);
}

//经纬度到屏幕映射
function latlngToScreen(latitude, longitude) {
    var latlng = L.latLng(latitude, longitude);
    var point = map.latLngToContainerPoint(latlng);
    // android window function
    mapjs.PointCallback(point.x * density, point.y * density);
}

if(!isAndroid){
    test();
}


