/**
 * Created by superping on 2014/7/16.
 */


function test() {
    var json = {
        "id": 1,
        "rotation": 90,
        "draggable": true,
        "icon": null,
        "height": 100,
        "width": 100,
        "latitude":  23.1740636,
        "longitude": 113.4093064,
        "visible": true,
        "anchorU": 0.5,
        "anchorV": 0.5
    }

    var json1 = {
        "id": 2,
        "rotation": 0,
        "draggable": true,
        "icon": null,
        "height": 100,
        "width": 100,
        "latitude": 23.1,
        "longitude": 113.4,
        "visible": true,
        "anchorU": 0.5,
        "anchorV": 0.5
    }
    var json2 = {
        "id": 3,
        "rotation": 0,
        "draggable": true,
        "icon": "icon/ic_waypoint_target.png",
        "height": 100,
        "width": 100,
        "latitude": 23.1,
        "longitude": 113.4,
        "visible": true,
        "anchorU": 0.5,
        "anchorV": 0.5
    }
    createMarker(json);
//    createMarker(json1);
//    createMarker(json2);
    var jsonSetvisible = {
        "id": 1,
        "property": "visible",
        "visible": true
    }

    var jsonSetvisible1 = {
        "id": 1,
        "property": "visible",
        "visible": false
    }

    var jsonSetvisible2 = {
        "id": 1,
        "property": "rotation",
        "rotation": 270
    }

    var jsonSetvisible3 = {
        "id": 1,
        "property": "rotation",
        "rotation": 290
    }

    var jsonSetvisible4 = {
        "id": 1,
        "property": "rotation",
        "rotation": 330
    }
//    setMarkerProperty(jsonSetvisible1);
//    setMarkerProperty(jsonSetvisible);
    sleep(1000);
    setMarkerProperty(jsonSetvisible2);

    var jsonProperty = {
        "id": 2,
        "property": "position"
    }
//    getMarkerProperty(jsonProperty);


    var jsonPolyline = {
        "id": 1,
        "color": 0xff00ff00,
        "latlngs": [
            {"latitude": 23.1,
                "longitude": 113.421},
            {"latitude": 23.11,
                "longitude": 113.42},
            {"latitude": 23.12,
                "longitude": 113.424},
            {"latitude": 23.13,
                "longitude": 113.423}
        ],
        "visible": true,
        "width": 5
    }
    createPolyline(jsonPolyline);
    var jsonchange = {
        "id": 1,
        "property": "color",
        "color": 0x880000ff
    }
    setPolylineProperty(jsonchange);

    jsonchange = {
        "id": 1,
        "property": "width",
        "width": 2
    }
    setPolylineProperty(jsonchange);

    screenToLatlng(500, 500);
}

function sleep(numberMillis) {
    var now = new Date();
    var exitTime = now.getTime() + numberMillis;
    while (true) {
        now = new Date();
        if (now.getTime() > exitTime)    return;
    }
}
var jsonSetvisible2 = {
    "id": 1,
    "property": "rotation",
    "rotation": 270
}
var rotation = 100;
document.onclick = function(){
    rotation += 10;
    jsonSetvisible2.rotation = rotation;
    setMarkerProperty(jsonSetvisible2);
}

//test();