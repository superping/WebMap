/**
 * Created by superping on 2014/7/10.
 */

var density = window.devicePixelRatio;
console.log("density:" + density);
var riseOffset = 100 * density;


var tiletemplateString;
var isAndroid = false;

if (L.Browser.android || L.Browser.android23) {
//    tiletemplateString = 'File:///mnt/sdcard/mapimage/satellite/tiles/{z}/{x}/{y}.png';
    tiletemplateString= "http://khm3.google.com/kh/v=155&hl=en&x={x}&y={y}&z={z}";
    isAndroid = true;
} else {
//    tiletemplateString = 'h:/mapimage/satellite/tiles/{z}/{x}/{y}.png';
    tiletemplateString= "http://khm3.google.com/kh/v=155&hl=en&x={x}&y={y}&z={z}";

}
var map;

function initMap(jsonText){
    var latitude = jsonText.latitude;
    var longitude = jsonText.longitude;
    var zoom = jsonText.zoom;
    if(latitude == undefined || longitude == undefined){
        latitude = 0;
        longitude = 0;
    }
    if(zoom == undefined){
        zoom = 16;
    }
    map = L.map('map',
        {
            keyboard:false,
            zoomControl:false,
            attributionControl: false
        }
    ).setView([ latitude, longitude ], zoom);

    L.tileLayer(tiletemplateString,
        {
            maxZoom: 20
        }).addTo(map);

    if (isAndroid) {
        mapjs.OnCameraChange(latitude, longitude, zoom, 0, 0);
    }

    map.on("drag", onCameraChange);
    map.on("zoomlevelschange", onCameraChange);
    map.on("zoomstart", onZoomStart)
    map.on("zoomend", onZoomEnd);
    map.on("click", onMapClick);
    map.on("load", onMapLoaded);
}


//initMap("12");


function onMapClick(e) {
    if (isAndroid) {
        mapjs.OnMapClick(e.latlng.lat, e.latlng.lng);
    }
}


function onMapLoaded(e) {
    console.log("load finsih");
    if (isAndroid) {
        mapjs.OnLoaded();
    }
}


function onCameraChange(e) {
    var latlng = map.getCenter();
    var zoom = map.getZoom();
    console.log("lat:" + latlng.lat + ",lng:" + latlng.lng + ",zoom:" + zoom);
    // android function
    if (isAndroid) {
        mapjs.OnCameraChange(latlng.lat, latlng.lng, zoom, 0, 0);
    }
}


var markerRequestArray = [];
var isZooming = false;
function onZoomStart(e) {
    isZooming = true;
}


function onZoomEnd(e) {
    isZooming = false;
    while (isZooming == false) {
        if (markerRequestArray.length == 0) {
            return;
        }
        var string = markerRequestArray.pop();
        setMarkerProperty(string);
    }
}

function onMarkerDragStart(e) {
    var marker = e.target;
    var markerItem = findItemByItem(markerArray, marker, 0, markerArray.length);
    // android window function
    if (isAndroid) {
        mapjs.OnMarkerDragStart(markerItem.id);
    }
}

function onMarkerDrag(e) {
    var marker = e.target;
    var markerItem = findItemByItem(markerArray, marker, 0, markerArray.length);
    // android window function
    if (isAndroid) {
        var latlng = markerItem.item.getLatLng();
        mapjs.OnMarkerDrag(markerItem.id, latlng.lat, latlng.lng);
    }

}

function onMarkerDragEnd(e) {
    var marker = e.target;
    var markerItem = findItemByItem(markerArray, marker, 0, markerArray.length);
    // android window function
    if (isAndroid) {
        mapjs.OnMarkerDragEnd(markerItem.id);
    }
}




var density;
function setDensity(densityparam) {
    density = densityparam;
}
String.prototype.replaceAll = function (s1, s2) {
    return this.replace(new RegExp(s1, "gm"), s2);
}
var MarkerSrc = "icon/ic_waypoint.png";
var MarkerString = "<div  class=\"plane-div-icon\" id = '{markerId}' style=\" width:{width}px; height:{height}px;align-self: center\"><img id ='{markerImageId}' src='{markerSrc}' style='width:{SrcWidth}px; height:{SrcHeight}px;-webkit-transform:rotate({SrcRotation}deg); -moz-transform:rotate({SrcRotation}deg);-ms-transform:rotate({SrcRotation}deg);-o-transform:rotate({SrcRotation}deg);transform:rotate({SrcRotation}deg)) '/></div>";
//var MarkerString = "<div  id = '{markerID}' style=\" width:{width}px; height:{height}px;align-self: center\"><img id ='{markerImageId}' src='{markerSrc}' style=' width:{width}px; height:{height}px;'/></div>";
var markerArray = [];

function MarkerItem(index, marker, width, height, anchorU, anchorV, rotation, createString) {
    this.id = index;
    this.item = marker;
    this.width = width;
    this.height = height;
    if (anchorU != undefined) {
        this.anchorU = anchorU;
    } else {
        this.anchorU = 0.5;
    }
    if (anchorV != undefined) {
        this.anchorV = anchorV;
    } else {
        this.anchorV = 0.5;
    }
    if (rotation != undefined) {
        this.rotation = rotation;
    } else {
        rotation = 0;
    }
    this.createString = createString;
}

function createMarker(jsonText) {
    console.log(JSON.stringify(jsonText));
    var id = jsonText.id;
    var createString;
    var width = 21;
    var height = 32;
    var rotation = 0;
    if (jsonText.icon != null) {
        width = jsonText.width / density;
        height = jsonText.height / density;
        rotation = jsonText.rotation;
        createString = MarkerString.replace("{markerId}", "item" + id).replace("{markerImageId}", "markerImage" + id).replace("{width}", width.toString()).replace("{height}", height.toString()).replace("{SrcWidth}", width.toString()).replace("{SrcHeight}", height.toString()).replaceAll("{SrcRotation}", rotation.toString());

        if (isAndroid) {
//        formImg.src = "data:image/png;base64," + jsonText.icon;
            createString = createString.replace("{markerSrc}", "data:image/png;base64," + jsonText.icon);
        } else {
            createString = createString.replace("{markerSrc}", jsonText.icon);
        }
    } else {
        rotation = jsonText.rotation;
        createString = MarkerString.replace("{markerId}", "item" + id).replace("{markerImageId}", "markerImage" + id).replace("{width}", width.toString()).replace("{height}", height.toString()).replace("{SrcWidth}", width.toString()).replace("{SrcHeight}", height.toString()).replaceAll("{SrcRotation}", rotation.toString());
        createString = createString.replace("{markerSrc}", "icon/ic_waypoint.png");
    }
    console.log(createString);
    var anchorU = width * jsonText.anchorU;
    var anchorV = height * jsonText.anchorV;
    console.log("anchor U:" + anchorU + " V:" + anchorV);
    var waypointIcon = L.divIcon(
        {className: 'plane-div-icon',
            html: createString,
            iconAnchor: [anchorU, anchorV]});
    var draggable = false;
    if (jsonText.draggable != undefined) draggable = jsonText.draggable;
    var marker = L.marker([jsonText.latitude, jsonText.longitude], {
            icon: waypointIcon,
            draggable: draggable,
            clickable: true
        }
    )
    if (jsonText.visible == true) {
        marker.addTo(map);
    }
    marker.on('dragstart', onMarkerDragStart);
    marker.on('drag', onMarkerDrag);
    marker.on('dragend', onMarkerDragEnd);
    marker.on("click", onMarkerClick);
//    marker.dragging.disable();
//    marker.on('mousedown', onMarkerMousedown);
    var markerItem = new MarkerItem(id, marker, width, height, jsonText.anchorU, jsonText.anchorV, jsonText.rotation, createString);

    markerArray.push(markerItem);
}

function setMarkerProperty(jsonText) {
    if (isZooming == false) {
        console.log("set marker property");
        console.log(JSON.stringify(jsonText));
        var item = jsonText.property;
        var id = jsonText.id;
        var markerItem = findItemById(markerArray, id, 0, markerArray.length - 1);
        if (markerItem == null) {
            console.log("marker item" + id + " not found");
            return;
        }
        var marker = markerItem.item;
        if (item == "position") {
            var latitude = jsonText.latitude;
            var longitude = jsonText.longitude;
            marker.setLatLng(L.latLng(latitude, longitude));
            marker.update();
        } else if (item == "rotation") {
            var angle = jsonText.rotation;
            markerItem.rotation = angle;
            var rotateImg = document.getElementById("markerImage" + id);
            rotate(rotateImg, angle);
            marker.update();
        }
        else if (item == "draggable") {
            var draggable = jsonText.draggable;
            if (draggable == true) {
                marker.dragging.enable();
            } else {
                marker.dragging.disable();
            }
            marker.update();
        }
        else if (item == "icon") {
            console.log("set marker icon");
            var width = jsonText.width / density;
            var height = jsonText.height / density;
            var rotation = markerItem.rotation;
            var iconString = MarkerString.replace("{markerId}", "item" + id).replace("{markerImageId}", "markerImage" + id).replace("{width}", width.toString()).replace("{height}", height.toString()).replace("{SrcWidth}", width.toString()).replace("{SrcHeight}", height.toString()).replaceAll("{SrcRotation}", rotation.toString());
            iconString = iconString.replace("{markerSrc}", "data:image/png;base64," + jsonText.icon);
            console.log(iconString);
            var anchorU = width * markerItem.anchorU;
            var anchorV = height * markerItem.anchorV;
            var markerIcon = L.divIcon(
                {className: 'plane-div-icon',
                    html: iconString,
                    iconAnchor: [anchorU, anchorV]});
            marker.setIcon(markerIcon);
            marker.update();
        }
        else if (item == "visible") {
            if (jsonText.visible == true) {
                marker.addTo(map);
                console.log("set visible,add to map");
            } else {
                map.removeLayer(marker);
            }
            marker.update();
        }
        else if (item == "anchor") {
            if (jsonText.anchorU != undefined) {
                markerItem.anchorU = jsonText.anchorU;
            }
            if (jsonText.anchorV != undefined) {
                markerItem.anchorV = jsonText.anchorV;
            }
        }
    } else {
        markerRequestArray.push(jsonText);
    }
}

function getMarkerProperty(jsonText) {
    var id = jsonText.id;
    var markerItem = findItemById(markerArray, id, 0, markerArray.length - 1);
    if (markerItem == null) return;
    var property = jsonText.property;
    switch (property) {
        case "position":
            var latlng = markerItem.item.getLatLng();
            // android window function
            if (isAndroid) {
                mapjs.markerPositionReturn(id, latlng.lat, latlng.lng);
            }
            break;
        case "icon":
            break;
        case "anchor":
            break;

    }
}

function removeMarker(jsonText) {
    console.log("remove " + id);
    var id = jsonText.id;
    var markerItem = findItemById(markerArray, id, 0, markerArray.length - 1);
    map.removeLayer(markerItem.item);
    markerArray.remove(markerItem);
}

var polylineArray = [];

function PolylineItem(index, polyline) {
    this.id = index;
    this.item = polyline;
}


function createPolyline(jsonText) {
    console.log(JSON.stringify(jsonText));
    var id = jsonText.id;
    var count = jsonText.count;

    var latlngs = [];

    for (var index in (jsonText.latlngs)) {
        var latlngpoint = L.latLng(jsonText.latlngs[index].latitude, jsonText.latlngs[index].longitude);
        latlngs.push(latlngpoint);
    }
    var polyline = L.polyline(latlngs, {
        color: jsonText.color,
        weight: jsonText.width,
        clickable: false
    });
    var visible = true;
    if (jsonText.visible != undefined) {
        visible = jsonText.visible;
    }
    if (visible) {
        polyline.addTo(map);
    }
    var polylineItem = new PolylineItem(id, polyline);

    polylineArray.push(polylineItem);
}


function removePolyline(jsonText) {
    var id = jsonText.id;
    console.log("remove polyline" + id);
    var polylineItem = findItemById(polylineArray, id, 0, polylineArray.length - 1);
    map.removeLayer(polylineItem.item);
    polylineArray.remove(polylineItem);
}

function setPolylineProperty(jsonText) {
    console.log(JSON.stringify(jsonText));
    var id = jsonText.id;
    var count = jsonText.count;

    var property = jsonText.property;
    var polylineItem = findItemById(polylineArray, id, 0, polylineArray.length - 1);
    if (polylineItem == null) {
        console.log("polyline item" + id + " not found");
        return;
    }
    var polyline = polylineItem.item;
    switch (property) {
        case "latlngs":
            var latlngs = [];

            for (var index in (jsonText.latlngs)) {
                var latlngpoint = L.latLng(jsonText.latlngs[index].latitude, jsonText.latlngs[index].longitude);
                latlngs.push(latlngpoint);
            }
            polyline.setLatLngs(latlngs);
            polyline.redraw();
            console.log("set latlngs");
            break;
        case "color":
            console.log("set color");
            var color = jsonText.color;
            var alpha = (jsonText.color & 0xff000000);
            alpha = (alpha >>> 24) / 0x100;
            var red = (jsonText.color & 0x00ff0000) / 0x100000;
            var green = (jsonText.color & 0x0000ff00) / 0x1000;
            var blue = (jsonText.color & 0x000000ff) / 0x10;
            var polycolor = '#' + Math.floor(red).toString(16) + Math.floor(green).toString(16) + Math.floor(blue).toString(16);
            polyline.setStyle({
                color: polycolor,
                opacity: alpha
            });
            break;
        case "width":
            polyline.setStyle({
                weight: jsonText.width
            });
            polyline.redraw();
            break;
        case "visible":
            if (jsonText.visible == true) {
                polyline.addTo(map);
            } else {
                map.removeLayer(polyline);
            }
            polyline.redraw();
            break;
    }
//    polyline.update();
}


var timer;
function onMarkerClick(e) {
    var marker = e.target;
    var markerItem = findItemByItem(markerArray, marker, 0, markerArray.length);
    if (isAndroid) {
        mapjs.OnMarkerClick(markerItem.id);
    }
}


// BinarySearch
function findItemById(array, id, start, end) {
//    console.log("find" + id + "," + start + "," + array[start].id + "," + end + "," + array[end].id);
//    for (var i = start; i <= end; ++i) {
//        console.log(array[i].id);
//    }
    if (id == array[start].id) return array[start];
    if (id == array[end].id) return array[end];
    if (start == end) return null;

    var middle = Math.floor((start + end) / 2);
    if (middle < 0) middle = 0;
    if (middle == start || middle == end) return null;
    var middleItem = array[middle];
    if (middleItem == null) return null;
//    console.log("middle" + middle + "," + middleItem.id);
    if (middleItem.id == id) return middleItem;
    if (middleItem.id > id) return findItemById(array, id, start, middle);
    else  return findItemById(array, id, middle, end);
}

// BinarySearch
function findItemByItem(array, item, start, end) {
    for (var index = start; index <= end; index++) {
        if (array[index].item == item) {
            return array[index];
        }
    }
    return null;
}

function rotate(element, r) {
    element.style.MozTransform = "rotate(" + r + "deg)";
    element.style.webkitTransform = "rotate(" + r + "deg)";
    element.style.msTransform = "rotate(" + r + "deg)";
    element.style.OTransform = "rotate(" + r + "deg)";
    element.style.transform = "rotate(" + r + "deg)";
}

function screenToLatlng(x, y, sessionId) {
    var latlng = map.containerPointToLatLng(L.point(x / density, y / density));
    // android window function\
    if (isAndroid) {
        mapjs.LatLngCallback((latlng.lat), (latlng.lng), sessionId);
    }

}

function latlngToScreen(latitude, longitude) {
    var latlng = L.latLng(latitude, longitude);
    var point = map.latLngToContainerPoint(latlng);
    // android window function
    if (isAndroid) {
        var x = point.x * density;
        var y = point.y * density;
        mapjs.PointCallback(x, y, 0);
    }
}

function moveCamByCenter(jsonText) {

    var center;
    if (jsonText.centerLat != undefined && jsonText.centerLng != undefined) {
        center = L.latLng(jsonText.centerLat, jsonText.centerLng);
    }
    var zoom;
    if(jsonText.zoom != undefined){
        zoom = jsonText.zoom;
    }
    map.setView(center,zoom);
}

function moveCamByBound(jsonText) {
    var northeast;
    if (jsonText.northeastLat != undefined && jsonText.northeastLng != undefined) {
        northeast = L.latLng(jsonText.northeastLat, jsonText.northeastLng);
    }else{return;}
    var southwest;
    if (jsonText.southwestLat != undefined && jsonText.southwestLng != undefined) {
        southwest = L.latLng(jsonText.southwestLat, jsonText.southwestLng);
    }else{return;}
    var pad;
    if(jsonText.pad != undefined){
        pad = jsonText.pad;
    }else{
        return;
    }
    map.fitBounds(L.latLngBounds(southwest,northeast), {
        padding: L.point(pad/density, pad/density)
    });
}
